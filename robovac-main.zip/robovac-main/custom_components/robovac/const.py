"""Constants for the Eufy Robovac integration."""

DOMAIN = "robovac"
CONF_VACS = "vacuums"
CONF_PHONE_CODE = "phone_code"
