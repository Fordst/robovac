# Contributions

Contributions are welcome. If you use HA and a Eufy Vacuum and want to make improvmenets, get in touch. 


